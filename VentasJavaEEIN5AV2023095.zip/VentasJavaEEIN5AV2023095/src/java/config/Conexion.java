
package config;

import java.sql.Connection;


public class Conexion {
    Conexion conexion;
    
    public Connection Conexion(){
        
        return conexion;
    }
}
