
package modelo;

public class Empleado {
    private  int codigoEmpleado;
    private String DPIEmpleado;
    private String nombresEmlpleado;
    private String telefonoEmpleado;
    private String estado;
    private String usuario;

    public Empleado() {
    }

    public Empleado(int codigoEmpleado, String DPIEmpleado, String nombresEmlpleado, String telefonoEmpleado, String estado, String usuario) {
        this.codigoEmpleado = codigoEmpleado;
        this.DPIEmpleado = DPIEmpleado;
        this.nombresEmlpleado = nombresEmlpleado;
        this.telefonoEmpleado = telefonoEmpleado;
        this.estado = estado;
        this.usuario = usuario;
    }

    public int getCodigoEmpleado() {
        return codigoEmpleado;
    }

    public void setCodigoEmpleado(int codigoEmpleado) {
        this.codigoEmpleado = codigoEmpleado;
    }

    public String getDPIEmpleado() {
        return DPIEmpleado;
    }

    public void setDPIEmpleado(String DPIEmpleado) {
        this.DPIEmpleado = DPIEmpleado;
    }

    public String getNombresEmlpleado() {
        return nombresEmlpleado;
    }

    public void setNombresEmlpleado(String nombresEmlpleado) {
        this.nombresEmlpleado = nombresEmlpleado;
    }

    public String getTelefonoEmpleado() {
        return telefonoEmpleado;
    }

    public void setTelefonoEmpleado(String telefonoEmpleado) {
        this.telefonoEmpleado = telefonoEmpleado;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }
    
}
